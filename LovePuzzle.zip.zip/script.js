document.addEventListener("DOMContentLoaded", function () {
    const words = [
        { scrambled: "VDENOTHO", answer: "VENT HOOD", hint: "Removes smoke from the kitchen." },
        { scrambled: "SGLEMNRASO", answer: "LEMONGRASS", hint: "A plant used in soups and teas." },
        { scrambled: "FECTLSRIVO", answer: "ELECTRIC STOVE", hint: "Cooks food using electricity." },
		{ scrambled: "RYEEEPL-", answer: "Y-PEELER", hint: "Used to peel vegetables and fruits." },
		{ scrambled: "SULTNSEI", answer: "UTENSILS", hint: "Includes spoons, forks, and knives." } 
		
    ];

    const dares = [
        "💌 Write a love letter or poem(tamil)",
        "🎤 Sing a song for me",
        "💖 Convince me for 5 minutes (how you fell in love with me)"
    ];

    let hintsUsed = 0;
    const gameArea = document.getElementById("gameArea");
    const submitBtn = document.getElementById("submitBtn");
    const surpriseMessage = document.getElementById("surpriseMessage");
    const getHintBtn = document.getElementById("getHint");
    const hintText = document.getElementById("hintText");

    words.forEach((word, index) => {
        const div = document.createElement("div");
        div.classList.add("word-container");
        div.innerHTML = `
            <p><strong>${word.scrambled}</strong></p>
            <p class="hint-text">Hint: ${word.hint}</p>
            <input type="text" id="input-${index}" placeholder="Type your answer">
        `;
        gameArea.appendChild(div);
    });

    submitBtn.addEventListener("click", () => {
        let correct = true;

        words.forEach((word, index) => {
            const userInput = document.getElementById(`input-${index}`).value.toUpperCase();
            if (userInput !== word.answer) {
                correct = false;
            }
        });

        if (correct) {
            surpriseMessage.classList.remove("hidden");
        }
    });

    getHintBtn.addEventListener("click", () => {
        if (hintsUsed < 3) {
            hintText.textContent = dares[hintsUsed];
            hintsUsed++;
        } else {
            hintText.textContent = "No more hints left! 💕";
        }
    });
});
